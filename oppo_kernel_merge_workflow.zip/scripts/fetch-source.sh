#!/usr/bin/env bash
set -euo pipefail

URL="${1:?missing URL}"
DEST="${2:?missing destination}"

rm -rf "$DEST"
mkdir -p "$DEST"

echo "Fetching: $URL"

# Direct archive URLs and common archive endpoints.
if [[ "$URL" =~ \.(zip|tar|tar\.gz|tgz)(\?.*)?$ ]]; then
    tmp="/tmp/source_archive"
    rm -f "$tmp" "$tmp".*
    curl -L --fail --retry 3 -o "$tmp" "$URL"

    case "$URL" in
      *.zip*) unzip -q "$tmp" -d "$DEST" ;;
      *.tar.gz*|*.tgz*) tar -xzf "$tmp" -C "$DEST" ;;
      *.tar*) tar -xf "$tmp" -C "$DEST" ;;
    esac
else
    # First try Git. This supports public repositories and URLs ending in .git.
    if git ls-remote "$URL" HEAD >/dev/null 2>&1; then
        git clone --depth=1 "$URL" "$DEST"
    else
        # Fallback: treat it as a direct archive URL even without a .zip suffix.
        tmp="/tmp/source_archive"
        rm -f "$tmp"
        curl -L --fail --retry 3 -o "$tmp" "$URL"
        file "$tmp"
        if unzip -t "$tmp" >/dev/null 2>&1; then
            unzip -q "$tmp" -d "$DEST"
        elif tar -tf "$tmp" >/dev/null 2>&1; then
            tar -xf "$tmp" -C "$DEST"
        else
            echo "ERROR: URL is neither a reachable Git repository nor a supported archive."
            exit 1
        fi
    fi
fi

# Remove a single wrapper directory when an archive contains one.
shopt -s dotglob nullglob
items=("$DEST"/*)
if [ "${#items[@]}" -eq 1 ] && [ -d "${items[0]}" ]; then
    tmpdir="${DEST}.tmp"
    mv "${items[0]}" "$tmpdir"
    rm -rf "$DEST"
    mv "$tmpdir" "$DEST"
fi

echo "Source prepared at: $DEST"
