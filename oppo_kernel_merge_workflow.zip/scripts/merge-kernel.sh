#!/usr/bin/env bash
set -euo pipefail

BASE="${1:?base source required}"
DONOR="${2:?donor source required}"
OUT="${3:?output required}"
MODE="${4:-missing-only}"

rm -rf "$OUT"
mkdir -p "$OUT"

# Copy base tree first.
rsync -a --exclude='.git' "$BASE/" "$OUT/"

# Keep a report so every imported file can be audited.
REPORT="$OUT/MERGE_REPORT.txt"
: > "$REPORT"

echo "Base: $BASE" >> "$REPORT"
echo "Donor: $DONOR" >> "$REPORT"
echo "Mode: $MODE" >> "$REPORT"
echo >> "$REPORT"

if [ "$MODE" = "missing-only" ]; then
    # Only files absent from the base tree are imported.
    cd "$DONOR"
    find . -type f -not -path './.git/*' -print0 |
    while IFS= read -r -d '' f; do
        src="$DONOR/${f#./}"
        dst="$OUT/${f#./}"

        if [ ! -e "$dst" ]; then
            mkdir -p "$(dirname "$dst")"
            cp -a "$src" "$dst"
            echo "ADDED  ${f#./}" >> "$REPORT"
        fi
    done
else
    # Overlay donor on top of base, but preserve a report of changes.
    rsync -a --exclude='.git' --itemize-changes "$DONOR/" "$OUT/" \
      | tee -a "$REPORT"
fi

echo >> "$REPORT"
echo "Files in merged tree: $(find "$OUT" -type f | wc -l)" >> "$REPORT"
