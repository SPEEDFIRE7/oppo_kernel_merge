# Generic Oppo/Realme Kernel Merge Builder

This repository contains a GitHub Actions workflow for combining two kernel source trees and building the result.

## How to use

1. Create a GitHub repository.
2. Put `.github/workflows/kernel.yml` and `scripts/` into it.
3. Open **Actions → Merge and Build Kernel → Run workflow**.
4. Enter:
   - Base source URL
   - Donor/modified source URL
   - Kernel name
   - Optional defconfig
   - Optional custom build command
5. The workflow uploads the merged source and build output as an artifact.

### Supported source URLs

The fetcher accepts:
- public Git repositories
- `.git` URLs
- ZIP archives
- TAR/TAR.GZ archives
- archive URLs without a conventional `.zip` suffix, when the downloaded file is actually an archive

### Important

`missing-only` is intentionally conservative: it copies files that are absent from the Oppo/base tree but does not overwrite existing files.

For a kernel port, this is safer than blindly replacing the entire Oppo tree with a Realme tree. However, automatic merging cannot guarantee hardware compatibility. Defconfig, DTS/DTB, drivers, clocks, regulators, pinctrl, display/touch, camera and vendor-specific code may require manual adaptation.

The workflow therefore keeps `MERGE_REPORT.txt` and the complete merged tree in the artifact.
